<?php // php/footer.php — shared footer ?>

<footer>
  <div class="footer-grid">
    <div>
      <div class="footer-brand-name">
        <div class="brand-dot" style="width:10px;height:10px;background:var(--accent);border-radius:50%;box-shadow:0 0 10px var(--accent);"></div>
        Index Computer
      </div>
      <p class="footer-desc">Toko komputer terpercaya di Batam. Menyediakan laptop, PC rakitan, aksesoris, hardware, printer, dan layanan servis berkualitas.</p>
      <div class="footer-contact-item">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        <span><?= SITE_ADDRESS ?></span>
      </div>
      <div class="footer-contact-item">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8 9.91a16 16 0 0 0 6 6l.86-.86a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        <span><?= SITE_PHONE ?></span>
      </div>
      <div class="footer-contact-item">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <span><?= SITE_HOURS ?></span>
      </div>
    </div>

    <div>
      <div class="footer-col-title">Navigasi</div>
      <div class="footer-links">
        <a href="index.php">Beranda</a>
        <a href="products.php">Semua Produk</a>
        <a href="solutions.php">Solusi PC</a>
        <a href="services.php">Layanan</a>
        <a href="support.php">Kontak & Support</a>
      </div>
    </div>

    <div>
      <div class="footer-col-title">Kategori</div>
      <div class="footer-links">
        <a href="products.php?cat=laptop">Laptop</a>
        <a href="products.php?cat=pc-komputer">PC & Komputer</a>
        <a href="products.php?cat=aksesoris">Aksesoris</a>
        <a href="products.php?cat=hardware">Hardware & Spare Part</a>
        <a href="products.php?cat=printer">Printer & Tinta</a>
        <a href="products.php?cat=gaming">Gaming</a>
      </div>
    </div>

    <div>
      <div class="footer-col-title">Official Payments</div>
      <div class="payment-list">
        <div class="payment-item">
          <div class="payment-bank">BCA</div>
          <div class="payment-num">8325 1978 65</div>
        </div>
        <div class="payment-item">
          <div class="payment-bank">BRI</div>
          <div class="payment-num">0331 0155 7788 207</div>
        </div>
        <div class="payment-item">
          <div class="payment-bank">Mandiri</div>
          <div class="payment-num">1090 0017 72567</div>
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:8px;">A.N PT Sentral Index Komputindo</div>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <span>Copyright &copy; 2026 Index Computer. All Rights Reserved.</span>
    <span>
      <a href="products.php">Produk</a> &nbsp;·&nbsp;
      <a href="support.php">Kontak</a> &nbsp;·&nbsp;
      <a href="php/admin/index.php">Admin</a>
    </span>
  </div>
</footer>
<link rel="stylesheet" href="css/chatbot.css?v=2.0.8">

<!-- AI Chatbot Floating Widget -->
<button class="chatbot-trigger" id="chatbotTrigger" title="Tanya AI Assistant">
  <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
  </svg>
</button>

<div class="chatbot-window" id="chatbotWindow">
  <div class="chatbot-header">
    <div class="chatbot-avatar">🤖</div>
    <div class="chatbot-info">
      <div class="chatbot-title">Index AI Assistant</div>
      <div class="chatbot-status">Online</div>
    </div>
    <button class="chatbot-close" id="chatbotClose" title="Tutup Chat">
      <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    </button>
  </div>
  
  <div class="chatbot-body" id="chatbotBody">
    <!-- Bot Welcome Message -->
    <div class="chat-msg bot">
      <div class="chatbot-avatar">🤖</div>
      <div class="msg-bubble">
        Halo! Saya <strong>Index AI Assistant</strong>. Ada yang bisa saya bantu hari ini? 💻<br><br>
        Berikut beberapa hal yang bisa Anda tanyakan:
      </div>
    </div>
    
    <!-- Quick Options -->
    <div class="chatbot-quick">
      <button class="quick-btn" onclick="triggerQuickOption(this)">📍 Lokasi Toko & Jam Buka</button>
      <button class="quick-btn" onclick="triggerQuickOption(this)">💻 Daftar Harga Laptop</button>
      <button class="quick-btn" onclick="triggerQuickOption(this)">🛠️ Jasa Rakit PC Custom</button>
      <button class="quick-btn" onclick="triggerQuickOption(this)">📞 Nomor WhatsApp Toko</button>
    </div>
  </div>
  
  <div class="chatbot-footer">
    <input type="text" class="chatbot-input" id="chatbotInput" placeholder="Tulis pesan..." autocomplete="off">
    <button class="chatbot-send" id="chatbotSend" title="Kirim Pesan">
      <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"/>
      </svg>
    </button>
  </div>
</div>

<script src="js/chatbot.js"></script>
<script src="js/main.js?v=2.0.2"></script>
</body>
</html>